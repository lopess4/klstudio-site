import {motion} from 'motion/react';
import {Quote} from 'lucide-react';
import {TESTIMONIALS} from '../data/studioData';

export function Testimonials() {
  return (
    <section id="depoimentos" className="py-16 sm:py-24 bg-[#070B14] relative">
      <div className="metallic-divider absolute top-0 inset-x-0" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12 sm:mb-14">
          <p className="text-sm font-medium text-blue-400 mb-3">
            Resultados comprovados
          </p>
          <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white leading-[1.15] [text-wrap:balance]">
            Empresas que modernizaram sua presença e aumentaram o faturamento.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item, idx) => (
            <motion.figure
              key={item.id}
              initial={{opacity: 0, y: 14}}
              whileInView={{opacity: 1, y: 0}}
              viewport={{once: true, margin: '-60px'}}
              transition={{duration: 0.45, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1]}}
              className="rounded-2xl p-6 sm:p-7 metallic-border bg-[#0A1224] flex flex-col justify-between gap-6"
            >
              <div>
                <div className="flex items-center justify-between gap-3 mb-5">
                  <Quote className="w-5 h-5 text-blue-400 shrink-0" aria-hidden="true" />
                  <span className="text-xs font-medium text-slate-400">{item.city}</span>
                </div>

                <p className="text-xs sm:text-sm font-semibold text-blue-300 tabular-nums mb-3">
                  {item.outcome}
                </p>

                <blockquote className="text-sm sm:text-[15px] leading-[1.7] text-slate-200">
                  “{item.quote}”
                </blockquote>
              </div>

              <figcaption className="pt-5 border-t border-slate-200/10">
                <div className="text-sm font-semibold text-white">{item.name}</div>
                <div className="mt-0.5 text-xs text-slate-400">
                  {item.role} <span aria-hidden="true">·</span> {item.company}
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
