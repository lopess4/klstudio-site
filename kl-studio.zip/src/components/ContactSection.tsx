import {FormEvent, useState} from 'react';
import {motion} from 'motion/react';
import {ArrowUpRight, CheckCircle2, Instagram, MessageSquare} from 'lucide-react';
import {
  buildWhatsAppUrl,
  INSTAGRAM_HANDLE,
  INSTAGRAM_URL,
  WHATSAPP_DISPLAY,
} from '../data/studioData';

interface FormState {
  name: string;
  company: string;
  phone: string;
  serviceType: string;
  message: string;
}

const INITIAL_FORM: FormState = {
  name: '',
  company: '',
  phone: '',
  serviceType: 'Landing Page de Alta Conversão',
  message: '',
};

export function ContactSection() {
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setErrorMsg('');

    const trimmedName = form.name.trim();
    const trimmedPhone = form.phone.replace(/\D/g, '');
    const trimmedMessage = form.message.trim();

    if (trimmedName.length < 2) {
      setErrorMsg('Por favor, informe seu nome completo.');
      return;
    }

    if (trimmedPhone.length < 10) {
      setErrorMsg('Informe um número de WhatsApp válido com DDD.');
      return;
    }

    if (trimmedMessage.length < 10) {
      setErrorMsg('Conte brevemente sobre sua empresa ou objetivo com o site.');
      return;
    }

    const formattedBriefing = [
      `Olá, KL Studio! Me chamo ${trimmedName}.`,
      form.company.trim() ? `Empresa: ${form.company.trim()}.` : null,
      `WhatsApp para retorno: ${form.phone.trim()}.`,
      `Serviço desejado: ${form.serviceType}.`,
      `Objetivo do projeto: ${trimmedMessage}`,
    ]
      .filter(Boolean)
      .join(' ');

    const whatsappHref = buildWhatsAppUrl(formattedBriefing);
    setSubmittedUrl(whatsappHref);
  }

  return (
    <section id="contato" className="py-16 sm:py-24 relative">
      <div className="metallic-divider absolute top-0 inset-x-0" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          {/* Left column: Direct persuasive CTA & channels */}
          <motion.div
            initial={{opacity: 0, y: 14}}
            whileInView={{opacity: 1, y: 0}}
            viewport={{once: true, margin: '-60px'}}
            transition={{duration: 0.45, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-5 space-y-6"
          >
            <div>
              <p className="text-sm font-medium text-blue-400 mb-3">
                Orçamento rápido
              </p>
              <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white leading-[1.15] [text-wrap:balance]">
                Pronto para colocar seu novo site no ar ainda hoje?
              </h2>
              <p className="mt-4 text-base leading-relaxed text-slate-300">
                Preencha o resumo ao lado ou fale diretamente no WhatsApp da KL Studio. Respondemos rápido
                com proposta clara, prazo no mesmo dia e foco total no crescimento do seu faturamento.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-200/10 space-y-4">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between gap-4 p-4 rounded-xl metallic-border bg-[#0A1224] hover:border-slate-300/35 transition-colors duration-150 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-[#0E1930] metallic-border flex items-center justify-center text-white shrink-0">
                    <MessageSquare className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">WhatsApp comercial</div>
                    <div className="text-sm sm:text-base font-semibold text-white tabular-nums">
                      {WHATSAPP_DISPLAY}
                    </div>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" aria-hidden="true" />
              </a>

              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between gap-4 p-4 rounded-xl metallic-border bg-[#0A1224] hover:border-slate-300/35 transition-colors duration-150 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-[#0E1930] metallic-border flex items-center justify-center text-white shrink-0">
                    <Instagram className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">Instagram oficial</div>
                    <div className="text-sm sm:text-base font-semibold text-white">
                      {INSTAGRAM_HANDLE}
                    </div>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right column: Validated Lead Capture Form */}
          <motion.div
            initial={{opacity: 0, y: 14}}
            whileInView={{opacity: 1, y: 0}}
            viewport={{once: true, margin: '-60px'}}
            transition={{duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-7 rounded-2xl p-6 sm:p-8 metallic-border-strong bg-[#0A1224]"
          >
            {submittedUrl ? (
              <div className="py-6 space-y-5">
                <div className="inline-flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                  <CheckCircle2 className="w-5 h-5 shrink-0" aria-hidden="true" />
                  <span>Resumo preparado com sucesso</span>
                </div>

                <h3 className="font-display text-2xl font-bold text-white">
                  Falta apenas um clique para enviar no WhatsApp.
                </h3>

                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  Organizamos suas informações para agilizar seu atendimento. Clique no botão abaixo para abrir
                  a conversa diretamente com a KL Studio.
                </p>

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#05070B] bg-white hover:bg-slate-200 transition-colors rounded-xl min-h-[48px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                  >
                    <span>Solicitar orçamento no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      setSubmittedUrl(null);
                      setForm(INITIAL_FORM);
                    }}
                    className="inline-flex items-center justify-center px-5 py-3.5 text-sm font-medium text-slate-300 hover:text-white metallic-border rounded-xl min-h-[48px] transition-colors"
                  >
                    Enviar nova mensagem
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="contact-name" className="block text-xs font-medium text-slate-300 mb-2">
                      Seu nome *
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({...form, name: e.target.value})}
                      placeholder="Ex.: Mariana Oliveira"
                      className="w-full rounded-xl bg-[#05070B] metallic-border px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-company" className="block text-xs font-medium text-slate-300 mb-2">
                      Empresa ou segmento
                    </label>
                    <input
                      id="contact-company"
                      type="text"
                      value={form.company}
                      onChange={(e) => setForm({...form, company: e.target.value})}
                      placeholder="Ex.: Clínica Odontológica"
                      className="w-full rounded-xl bg-[#05070B] metallic-border px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 min-h-[44px]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="contact-phone" className="block text-xs font-medium text-slate-300 mb-2">
                      WhatsApp com DDD *
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      required
                      value={form.phone}
                      onChange={(e) => setForm({...form, phone: e.target.value})}
                      placeholder="(62) 99999-9999"
                      className="w-full rounded-xl bg-[#05070B] metallic-border px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-service" className="block text-xs font-medium text-slate-300 mb-2">
                      Tipo de projeto
                    </label>
                    <select
                      id="contact-service"
                      value={form.serviceType}
                      onChange={(e) => setForm({...form, serviceType: e.target.value})}
                      className="w-full rounded-xl bg-[#05070B] metallic-border px-4 py-3 text-sm text-white focus:outline-none focus:border-blue-400 min-h-[44px]"
                    >
                      <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                      <option value="Site Institucional Corporativo">Site Institucional Corporativo</option>
                      <option value="Vitrine Digital / Catálogo">Vitrine Digital / Catálogo</option>
                      <option value="Redesign de Site Existente">Redesign de Site Existente</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="contact-message" className="block text-xs font-medium text-slate-300 mb-2">
                    Sobre o seu projeto *
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    required
                    value={form.message}
                    onChange={(e) => setForm({...form, message: e.target.value})}
                    placeholder="Conte o que sua empresa vende e qual resultado você espera alcançar com o novo site."
                    className="w-full rounded-xl bg-[#05070B] metallic-border px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 resize-y"
                  />
                </div>

                {errorMsg && (
                  <p role="alert" className="text-sm font-medium text-amber-300">
                    {errorMsg}
                  </p>
                )}

                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <span className="text-xs text-slate-400">
                    Entrega no mesmo dia <span aria-hidden="true">·</span> Atendimento em todo o Brasil
                  </span>

                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#05070B] bg-white hover:bg-slate-200 transition-colors duration-150 rounded-xl whitespace-nowrap shrink-0 min-h-[48px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                  >
                    <span>Solicitar orçamento no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
