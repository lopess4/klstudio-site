import {motion} from 'motion/react';
import {ArrowUpRight} from 'lucide-react';
import {ABOUT_IMAGE, buildWhatsAppUrl} from '../data/studioData';
import {ResilientImage} from './ResilientImage';

const PILLARS = [
  {
    index: '01.',
    title: 'Velocidade que acompanha o seu negócio',
    description:
      'Enquanto agências tradicionais levam semanas em reuniões intermináveis, estruturamos e entregamos seu site completo no mesmo dia para você começar a vender imediatamente.',
  },
  {
    index: '02.',
    title: 'Estética premium que justifica seu preço',
    description:
      'Visual escuro de alto contraste, detalhes metálicos e tipografia precisa elevam a percepção de valor da sua marca e aumentam a confiança de quem visita sua página.',
  },
  {
    index: '03.',
    title: 'Foco absoluto em retorno financeiro',
    description:
      'Cada seção, título e botão é posicionado estrategicamente para conduzir o visitante pelo funil de decisão até clicar e solicitar orçamento no seu WhatsApp.',
  },
];

export function About() {
  return (
    <section id="sobre" className="py-16 sm:py-24 relative">
      <div className="metallic-divider mb-16 sm:mb-24" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch gap-8 lg:gap-14">
          {/* Visual Column */}
          <motion.div
            initial={{opacity: 0, y: 16}}
            whileInView={{opacity: 1, y: 0}}
            viewport={{once: true, margin: '-80px'}}
            transition={{duration: 0.5, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-5"
          >
            <div className="relative h-full min-h-[280px] sm:min-h-[360px] rounded-2xl overflow-hidden metallic-border bg-[#0A1224]">
              <ResilientImage
                src={ABOUT_IMAGE}
                alt="Estação de trabalho minimalista da KL Studio dedicada à criação de sites profissionais"
                className="w-full h-full lg:h-full object-cover"
                fallbackTitle="KL Studio — Desenvolvimento & Design"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/85 via-transparent to-transparent"
              />
              <div className="absolute bottom-0 inset-x-0 p-6">
                <p className="text-xs font-medium text-slate-300">
                  Atendimento em todo o Brasil <span aria-hidden="true" className="mx-1.5 text-slate-500">·</span> @kl_studioo01
                </p>
                <p className="mt-1 font-display text-lg font-semibold text-white">
                  Compromisso com tecnologia, criatividade e resultado.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Editorial Content Column */}
          <motion.div
            initial={{opacity: 0, y: 16}}
            whileInView={{opacity: 1, y: 0}}
            viewport={{once: true, margin: '-80px'}}
            transition={{duration: 0.5, delay: 0.08, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-7 flex flex-col justify-between"
          >
            <div>
              <p className="text-sm font-medium text-blue-400 mb-3">
                Sobre a KL Studio
              </p>
              <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white leading-[1.15] [text-wrap:balance]">
                Desenvolvimento web independente feito para empresas que não podem esperar.
              </h2>

              <p className="mt-5 text-base leading-[1.7] tracking-[0.01em] text-slate-300">
                A KL Studio é um estúdio independente de desenvolvimento web e design, dedicado a transformar ideias
                em experiências digitais modernas e funcionais. Criamos sites profissionais, personalizados e
                responsivos, pensados para fortalecer marcas, destacar negócios e ampliar sua presença no ambiente
                digital. Nosso compromisso é unir tecnologia, criatividade e qualidade para entregar soluções que
                conectam empresas aos seus clientes.
              </p>
            </div>

            {/* Clean horizontal dividers separating pillars instead of nested boxes */}
            <div className="mt-8 divide-y divide-slate-200/10 border-t border-b border-slate-200/10">
              {PILLARS.map((pillar) => (
                <div key={pillar.index} className="py-4 sm:py-5 grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4">
                  <div className="sm:col-span-5 flex items-baseline gap-2.5">
                    <span className="font-mono text-xs text-slate-400 tabular-nums">{pillar.index}</span>
                    <h3 className="text-sm sm:text-base font-semibold text-white">{pillar.title}</h3>
                  </div>
                  <p className="sm:col-span-7 text-sm leading-relaxed text-slate-400">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <a
                href={buildWhatsAppUrl('Olá, KL Studio! Li sobre o trabalho do estúdio e quero solicitar um orçamento para minha empresa.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-blue-300 transition-colors duration-150 py-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-sm"
              >
                <span>Conversar diretamente pelo WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
