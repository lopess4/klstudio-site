import {useEffect, useState} from 'react';
import {AnimatePresence, motion} from 'motion/react';
import {ArrowUpRight, Maximize2, X} from 'lucide-react';
import {
  buildWhatsAppUrl,
  PORTFOLIO_PROJECTS,
  ProjectCategory,
  ProjectItem,
} from '../data/studioData';
import {ResilientImage} from './ResilientImage';

const CATEGORIES: ProjectCategory[] = ['Todos', 'Institucional', 'Alta Conversão', 'Vitrine'];

export function Portfolio() {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('Todos');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const filteredProjects =
    activeCategory === 'Todos'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((project) => project.category === activeCategory);

  useEffect(() => {
    if (!selectedProject) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section id="portfolio" className="py-16 sm:py-24 relative">
      <div className="metallic-divider absolute top-0 inset-x-0" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 sm:mb-12">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-blue-400 mb-3">
              Portfólio selecionado
            </p>
            <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white leading-[1.15] [text-wrap:balance]">
              Projetos criados para posicionar marcas e acelerar vendas.
            </h2>
          </div>

          {/* Interactive category filter segmented control */}
          <div
            role="tablist"
            aria-label="Filtrar projetos por categoria"
            className="inline-flex flex-wrap items-center gap-1 p-1 rounded-xl metallic-border bg-[#0A1224] self-start md:self-auto"
          >
            {CATEGORIES.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(category)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white ${
                    isActive
                      ? 'bg-white text-[#05070B] shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-[#0E1930]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Bento Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {filteredProjects.map((project, index) => {
            const isHeroTile = activeCategory === 'Todos' && index === 0;
            return (
              <motion.article
                key={project.id}
                layout
                initial={{opacity: 0, y: 14}}
                whileInView={{opacity: 1, y: 0}}
                viewport={{once: true, margin: '-60px'}}
                transition={{duration: 0.4, ease: [0.16, 1, 0.3, 1]}}
                className={`group rounded-2xl overflow-hidden metallic-border bg-[#0A1224] flex flex-col justify-between transition-colors duration-200 hover:border-slate-300/35 ${
                  isHeroTile ? 'lg:col-span-12 lg:grid lg:grid-cols-12' : 'lg:col-span-6'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setSelectedProject(project)}
                  aria-label={`Abrir detalhes do projeto ${project.title}`}
                  className={`relative block w-full text-left overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white ${
                    isHeroTile ? 'lg:col-span-7 aspect-[16/10] lg:aspect-auto lg:h-full min-h-[260px]' : 'aspect-[4/3]'
                  }`}
                >
                  <ResilientImage
                    src={project.image}
                    alt={`${project.title} — ${project.client}`}
                    className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                    fallbackTitle={project.title}
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/70 via-transparent to-transparent"
                  />
                  <span className="absolute top-4 right-4 w-10 h-10 rounded-lg bg-[#05070B]/80 metallic-border text-white flex items-center justify-center opacity-90 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4" aria-hidden="true" />
                  </span>
                </button>

                <div
                  className={`p-6 sm:p-8 flex flex-col justify-between gap-6 ${
                    isHeroTile ? 'lg:col-span-5' : ''
                  }`}
                >
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="text-blue-300 font-medium">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{project.year}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.deliveryTime}</span>
                    </div>

                    <h3 className="mt-3 font-display text-xl sm:text-2xl font-bold text-white tracking-tight">
                      {project.title}
                    </h3>

                    <p className="mt-1 text-sm font-medium text-slate-300">{project.client}</p>

                    <p className="mt-4 text-sm leading-relaxed text-slate-300">
                      {project.summary}
                    </p>

                    <div className="mt-5 pt-4 border-t border-slate-200/10">
                      <p className="text-xs text-slate-400">Resultado apurado</p>
                      <p className="mt-1 text-sm font-semibold text-white tabular-nums">
                        {project.impactMetric}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-200/10">
                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="text-sm font-medium text-slate-200 hover:text-white underline underline-offset-4 decoration-slate-500 hover:decoration-white transition-colors py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-sm"
                    >
                      Ver estudo de caso
                    </button>

                    <a
                      href={buildWhatsAppUrl(
                        `Olá, KL Studio! Vi o projeto "${project.title}" no portfólio e quero solicitar um orçamento parecido para minha empresa.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-white hover:text-blue-300 transition-colors py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-sm"
                    >
                      <span>Quero um site assim</span>
                      <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{opacity: 0}}
            animate={{opacity: 1}}
            exit={{opacity: 0}}
            transition={{duration: 0.2}}
            className="fixed inset-0 z-50 bg-[#05070B]/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
            role="dialog"
            aria-modal="true"
            aria-labelledby="lightbox-title"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{opacity: 0, scale: 0.97, y: 12}}
              animate={{opacity: 1, scale: 1, y: 0}}
              exit={{opacity: 0, scale: 0.97, y: 12}}
              transition={{duration: 0.22, ease: [0.16, 1, 0.3, 1]}}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-4xl rounded-2xl overflow-hidden metallic-border-strong bg-[#0A1224] shadow-2xl my-auto"
            >
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                aria-label="Fechar visualização do projeto"
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-lg bg-[#05070B]/90 metallic-border text-white hover:bg-white hover:text-[#05070B] transition-colors flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>

              <div className="aspect-[16/9] w-full bg-[#05070B]">
                <ResilientImage
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                  fallbackTitle={selectedProject.title}
                />
              </div>

              <div className="p-6 sm:p-8 space-y-6">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="text-blue-300 font-medium">{selectedProject.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.client}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{selectedProject.year}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.deliveryTime}</span>
                </div>

                <div>
                  <h3 id="lightbox-title" className="font-display text-2xl sm:text-3xl font-bold text-white">
                    {selectedProject.title}
                  </h3>
                  <p className="mt-2 text-base font-semibold text-blue-300 tabular-nums">
                    {selectedProject.impactMetric}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-200/10">
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Desafio do cliente
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">
                      {selectedProject.challenge}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                      Solução KL Studio
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">
                      {selectedProject.solution}
                    </p>
                  </div>
                </div>

                <div className="pt-5 border-t border-slate-200/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="text-xs text-slate-400">
                    Tecnologias e foco:{' '}
                    <span className="text-slate-200">{selectedProject.stack.join(' · ')}</span>
                  </div>

                  <a
                    href={buildWhatsAppUrl(
                      `Olá, KL Studio! Quero solicitar um orçamento para um projeto no padrão de "${selectedProject.title}".`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-[#05070B] bg-white hover:bg-slate-200 transition-colors rounded-xl whitespace-nowrap shrink-0 min-h-[44px]"
                  >
                    <span>Solicitar orçamento no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
