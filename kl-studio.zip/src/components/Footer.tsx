import {buildWhatsAppUrl, INSTAGRAM_HANDLE, INSTAGRAM_URL, WHATSAPP_DISPLAY} from '../data/studioData';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-200/12 bg-[#05070B] py-12">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-8 border-b border-slate-200/10">
          <div>
            <a href="#inicio" className="font-display text-lg font-bold text-white tracking-tight">
              KL Studio
            </a>
            <p className="mt-2 text-sm text-slate-400 max-w-sm">
              Sua ideia merece uma presença digital à altura. Criação de sites profissionais no Brasil com
              entrega no mesmo dia.
            </p>
          </div>

          <nav aria-label="Links do rodapé" className="flex flex-wrap items-center gap-6 text-sm text-slate-300">
            <a href="#sobre" className="hover:text-white transition-colors">
              Sobre
            </a>
            <a href="#servicos" className="hover:text-white transition-colors">
              Serviços
            </a>
            <a href="#portfolio" className="hover:text-white transition-colors">
              Portfólio
            </a>
            <a href="#depoimentos" className="hover:text-white transition-colors">
              Depoimentos
            </a>
            <a href="#contato" className="hover:text-white transition-colors">
              Contato
            </a>
          </nav>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-400">
          <p className="tabular-nums">
            © {currentYear} KL Studio. Todos os direitos reservados.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors tabular-nums"
            >
              WhatsApp: {WHATSAPP_DISPLAY}
            </a>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              Instagram: {INSTAGRAM_HANDLE}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
