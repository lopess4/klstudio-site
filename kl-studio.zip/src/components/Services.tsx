import {motion} from 'motion/react';
import {ArrowUpRight, Check} from 'lucide-react';
import {buildWhatsAppUrl, SERVICES} from '../data/studioData';

export function Services() {
  return (
    <section id="servicos" className="py-16 sm:py-24 bg-[#070B14] relative">
      <div className="metallic-divider absolute top-0 inset-x-0" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12 sm:mb-14">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-blue-400 mb-3">
              Serviços de criação de sites
            </p>
            <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white leading-[1.15] [text-wrap:balance]">
              Soluções sob medida para transformar acessos em faturamento.
            </h2>
          </div>

          <p className="text-sm sm:text-base text-slate-300 max-w-md leading-relaxed">
            Todos os projetos contam com layout exclusivo, responsividade total e entrega no mesmo dia para
            acelerar suas vendas.
          </p>
        </div>

        {/* Asymmetric Bento Grid (col-span-2 paired with col-span-1) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SERVICES.map((service, idx) => (
            <motion.article
              key={service.number}
              initial={{opacity: 0, y: 16}}
              whileInView={{opacity: 1, y: 0}}
              viewport={{once: true, margin: '-60px'}}
              transition={{duration: 0.45, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1]}}
              className={`group rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-colors duration-200 metallic-border hover:border-slate-300/30 ${
                service.featured
                  ? 'md:col-span-2 bg-gradient-to-br from-[#0E1930] via-[#0A1224] to-[#080D18]'
                  : 'md:col-span-1 bg-[#0A1224]'
              }`}
            >
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium text-slate-400 mb-5">
                  <span className="font-mono text-slate-300 tabular-nums">{service.number}</span>
                  <span>
                    {service.deliveryNote} <span aria-hidden="true" className="mx-1.5 text-slate-600">·</span> 100% Responsivo
                  </span>
                </div>

                <h3 className="font-display text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {service.title}
                </h3>
                <p className="mt-1.5 text-sm font-medium text-blue-300">
                  {service.subtitle}
                </p>

                <p className="mt-4 text-sm sm:text-[15px] leading-relaxed text-slate-300">
                  {service.description}
                </p>

                <ul className="mt-6 space-y-2.5 border-t border-slate-200/10 pt-5">
                  {service.deliverables.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm text-slate-200">
                      <Check className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" aria-hidden="true" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 pt-5 border-t border-slate-200/10 flex items-center justify-between gap-4">
                <a
                  href={buildWhatsAppUrl(service.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-white group-hover:text-blue-300 transition-colors duration-150 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white rounded-sm"
                >
                  <span>Solicitar orçamento no WhatsApp</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
                </a>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
