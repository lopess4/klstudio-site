import {motion} from 'motion/react';
import {ArrowUpRight, ArrowDownRight} from 'lucide-react';
import {buildWhatsAppUrl, HERO_IMAGE, HERO_METRICS} from '../data/studioData';
import {ResilientImage} from './ResilientImage';

export function Hero() {
  return (
    <section id="inicio" className="relative pt-10 pb-16 sm:pt-14 sm:pb-20 lg:pt-16 lg:pb-24 overflow-hidden">
      {/* Subtle deep navy ambient glow behind hero canvas */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 right-0 w-[640px] h-[520px] rounded-full bg-[#1E3A8A]/20 blur-[130px]"
      />

      <div className="relative max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split-Screen Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch gap-8 lg:gap-12">
          {/* Left column: Typographic hierarchy & primary action */}
          <motion.div
            initial={{opacity: 0, y: 14}}
            animate={{opacity: 1, y: 0}}
            transition={{duration: 0.45, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-6 flex flex-col justify-between py-2"
          >
            <div>
              <p className="text-xs sm:text-sm font-medium tracking-[0.04em] text-slate-300 mb-5">
                Estúdio independente <span aria-hidden="true" className="mx-1.5 text-slate-500">·</span> Brasil{' '}
                <span aria-hidden="true" className="mx-1.5 text-slate-500">·</span> Entrega no mesmo dia
              </p>

              <h1 className="font-display text-[clamp(2.25rem,4vw,3.75rem)] font-bold leading-[1.08] tracking-tight text-white [text-wrap:balance]">
                Sua ideia merece uma presença digital à altura.
              </h1>

              <p className="mt-6 text-base sm:text-[17px] leading-[1.65] tracking-[0.01em] text-slate-300 max-w-xl">
                Desenvolvemos sites profissionais, personalizados e responsivos com entrega no mesmo dia —
                projetados para empresas que querem fortalecer a marca, superar a concorrência e aumentar o
                faturamento já nesta semana.
              </p>
            </div>

            <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row sm:items-center gap-4">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm sm:text-base font-semibold text-[#05070B] bg-white hover:bg-slate-200 transition-colors duration-150 rounded-xl whitespace-nowrap shrink-0 min-h-[48px] shadow-[0_0_0_1px_rgba(255,255,255,0.25)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#05070B]"
              >
                <span>Solicitar orçamento no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm sm:text-base font-medium text-slate-200 hover:text-white metallic-border bg-[#0A1224]/70 hover:bg-[#0E1930] transition-colors duration-150 rounded-xl whitespace-nowrap shrink-0 min-h-[48px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <span>Ver projetos</span>
                <ArrowDownRight className="w-4 h-4 shrink-0 text-slate-400" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right column: Dominant 16:9 / framed architectural showcase */}
          <motion.div
            initial={{opacity: 0, scale: 0.985}}
            animate={{opacity: 1, scale: 1}}
            transition={{duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1]}}
            className="lg:col-span-6"
          >
            <div className="relative h-full min-h-[260px] sm:min-h-[340px] lg:min-h-[420px] rounded-2xl overflow-hidden metallic-border-strong bg-[#0A1224]">
              <ResilientImage
                src={HERO_IMAGE}
                alt="Ambiente digital da KL Studio com arquitetura escura, detalhes metálicos e interface de alto contraste"
                className="w-full h-full lg:h-full object-cover"
                fallbackTitle="KL Studio — Arquitetura Web de Alto Padrão"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/75 via-[#05070B]/15 to-transparent"
              />
              <div className="absolute bottom-0 inset-x-0 p-5 sm:p-6 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-slate-300">
                    Design sob medida <span aria-hidden="true" className="mx-1.5 text-slate-500">/</span> Padrão corporativo
                  </p>
                  <p className="mt-1 text-sm sm:text-base font-semibold text-white">
                    Do briefing à publicação no ar no mesmo dia
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-width 4-column KPI Strip below the hero split */}
        <motion.div
          initial={{opacity: 0, y: 12}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.45, delay: 0.16, ease: [0.16, 1, 0.3, 1]}}
          className="mt-10 sm:mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-slate-200/12 rounded-2xl overflow-hidden metallic-border"
        >
          {HERO_METRICS.map((metric) => (
            <div
              key={metric.label}
              className="bg-[#080E1B] p-5 sm:p-6 flex flex-col justify-between gap-2"
            >
              <div className="font-display text-xl sm:text-2xl font-bold text-white tabular-nums tracking-tight">
                {metric.value}
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-100">{metric.label}</div>
                <p className="mt-1 text-xs sm:text-sm leading-relaxed text-slate-400">
                  {metric.detail}
                </p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
