import {useState} from 'react';
import {Monitor} from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export function ResilientImage({
  src,
  alt,
  className = 'w-full h-full object-cover',
  fallbackTitle,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className="w-full h-full flex flex-col items-center justify-center gap-3 p-6 bg-gradient-to-br from-[#0A1224] via-[#070B14] to-[#05070B] text-slate-300"
      >
        <div className="w-12 h-12 rounded-xl metallic-border bg-[#0E1930]/80 flex items-center justify-center text-slate-200">
          <Monitor className="w-6 h-6" aria-hidden="true" />
        </div>
        {fallbackTitle && (
          <span className="text-sm font-medium text-center text-slate-200 max-w-xs">
            {fallbackTitle}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
