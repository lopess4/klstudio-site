import {MessageCircle} from 'lucide-react';
import {buildWhatsAppUrl} from '../data/studioData';

export function FloatingWhatsApp() {
  return (
    <a
      href={buildWhatsAppUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento no WhatsApp"
      className="fixed bottom-5 right-5 z-40 inline-flex items-center justify-center gap-2.5 h-12 w-12 sm:w-auto sm:px-5 rounded-full bg-white text-[#05070B] hover:bg-slate-200 transition-all duration-150 shadow-[0_10px_30px_rgba(0,0,0,0.55)] ring-1 ring-slate-300/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#05070B]"
    >
      <MessageCircle className="w-5 h-5 shrink-0 text-[#05070B]" aria-hidden="true" />
      <span className="hidden sm:inline text-sm font-semibold whitespace-nowrap">
        Orçamento no WhatsApp
      </span>
    </a>
  );
}
