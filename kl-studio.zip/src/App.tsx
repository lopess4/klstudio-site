/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {MotionConfig} from 'motion/react';
import {Navbar} from './components/Navbar';
import {Hero} from './components/Hero';
import {About} from './components/About';
import {Services} from './components/Services';
import {Portfolio} from './components/Portfolio';
import {Testimonials} from './components/Testimonials';
import {ContactSection} from './components/ContactSection';
import {Footer} from './components/Footer';
import {FloatingWhatsApp} from './components/FloatingWhatsApp';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#05070B] text-white flex flex-col">
        <Navbar />
        <main className="flex-1">
          <Hero />
          <About />
          <Services />
          <Portfolio />
          <Testimonials />
          <ContactSection />
        </main>
        <Footer />
        <FloatingWhatsApp />
      </div>
    </MotionConfig>
  );
}
