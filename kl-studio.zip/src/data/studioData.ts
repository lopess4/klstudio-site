export const WHATSAPP_NUMBER = '5562993156698';
export const WHATSAPP_DISPLAY = '+55 (62) 99315-6698';
export const INSTAGRAM_HANDLE = '@kl_studioo01';
export const INSTAGRAM_URL = 'https://instagram.com/kl_studioo01';

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMessage =
    'Olá, KL Studio! Quero solicitar um orçamento para criar um site profissional com entrega no mesmo dia.';
  const text = encodeURIComponent(customMessage || defaultMessage);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

export const HERO_IMAGE = '/src/assets/images/hero_kl_studio_1795547817454.jpg';
export const ABOUT_IMAGE = '/src/assets/images/about_kl_workspace_1795547817501.jpg';

export interface MetricItem {
  value: string;
  label: string;
  detail: string;
}

export const HERO_METRICS: MetricItem[] = [
  {
    value: 'Mesmo dia',
    label: 'Prazo de entrega',
    detail: 'Do briefing ao site no ar em horas, sem semanas de espera.',
  },
  {
    value: '100%',
    label: 'Responsivo e veloz',
    detail: 'Carregamento instantâneo em celulares, tablets e desktops.',
  },
  {
    value: 'WCAG AA',
    label: 'Contraste e leitura',
    detail: 'Hierarquia visual pensada para guiar o cliente até a compra.',
  },
  {
    value: 'Brasil',
    label: 'Atendimento direto',
    detail: 'Comunicação sem intermediários diretamente pelo WhatsApp.',
  },
];

export interface ServiceItem {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  deliveryNote: string;
  whatsappMessage: string;
  featured?: boolean;
}

export const SERVICES: ServiceItem[] = [
  {
    number: '01.',
    title: 'Landing Pages de Alta Conversão',
    subtitle: 'Estrutura focada em gerar contatos e vendas diárias',
    description:
      'Páginas estratégicas desenhadas para transformar visitantes de anúncios e redes sociais em pedidos reais no seu WhatsApp. Copywriting persuasivo, velocidade extrema e design que impõe autoridade imediata.',
    deliverables: [
      'Arquitetura persuasiva orientada à ação',
      'Integração direta com WhatsApp e formulários',
      'Otimização para tráfego pago (Meta e Google Ads)',
    ],
    deliveryNote: 'Entrega no mesmo dia',
    whatsappMessage:
      'Olá, KL Studio! Tenho interesse em uma Landing Page de Alta Conversão com entrega no mesmo dia. Gostaria de um orçamento.',
    featured: true,
  },
  {
    number: '02.',
    title: 'Sites Institucionais Corporativos',
    subtitle: 'Autoridade digital para empresas que disputam grandes contratos',
    description:
      'Apresente sua empresa, serviços e diferenciais com acabamento de alto padrão. Ideal para escritórios, clínicas, consultorias e negócios que precisam transmitir solidez logo no primeiro acesso.',
    deliverables: [
      'Design exclusivo alinhado à sua marca',
      'Seções de serviços, portfólio e prova social',
      'SEO técnico estruturado para buscas no Google',
    ],
    deliveryNote: 'Entrega no mesmo dia',
    whatsappMessage:
      'Olá, KL Studio! Gostaria de solicitar um orçamento para um Site Institucional Corporativo.',
  },
  {
    number: '03.',
    title: 'Vitrines Digitais e Catálogos',
    subtitle: 'Exposição elegante de produtos com fechamento ágil',
    description:
      'Mostre seu catálogo de produtos ou imóveis com navegação fluida, filtros inteligentes e botões de solicitação de orçamento direto por item para acelerar o ciclo comercial da sua equipe.',
    deliverables: [
      'Filtros dinâmicos por categoria',
      'Visualização detalhada em alta definição',
      'Botão de pedido direto por produto no WhatsApp',
    ],
    deliveryNote: 'Entrega no mesmo dia',
    whatsappMessage:
      'Olá, KL Studio! Quero um orçamento para criar uma Vitrine Digital / Catálogo para minha empresa.',
  },
  {
    number: '04.',
    title: 'Redesign e Reposicionamento de Marca',
    subtitle: 'Modernização completa para sites lentos ou ultrapassados',
    description:
      'Um site amador faz sua empresa perder clientes antes mesmo do primeiro contato. Reconstruímos sua presença digital com visual escuro, limpo ou corporativo, garantindo performance mobile impecável.',
    deliverables: [
      'Auditoria de conversão e legibilidade',
      'Nova identidade visual de interface',
      'Migração rápida sem tirar sua empresa do ar',
    ],
    deliveryNote: 'Entrega no mesmo dia',
    whatsappMessage:
      'Olá, KL Studio! Preciso modernizar o site atual da minha empresa com um redesign profissional.',
    featured: true,
  },
];

export type ProjectCategory = 'Todos' | 'Institucional' | 'Alta Conversão' | 'Vitrine';

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'Todos'>;
  year: string;
  deliveryTime: string;
  impactMetric: string;
  image: string;
  summary: string;
  challenge: string;
  solution: string;
  stack: string[];
  featured?: boolean;
}

export const PORTFOLIO_PROJECTS: ProjectItem[] = [
  {
    id: 'aethelred-wealth',
    title: 'Plataforma Institucional — Assessoria Patrimonial',
    client: 'Aethelred Capital Brasil',
    category: 'Institucional',
    year: '2026',
    deliveryTime: 'Entregue em 8 horas',
    impactMetric: '+165% agendamentos qualificados nos primeiros 60 dias',
    image: '/src/assets/images/project_fintech_luxury_1795547819225.jpg',
    summary:
      'Portal corporativo em azul marinho e acabamento metálico desenvolvido para transmitir confiança a investidores de alto patrimônio e centralizar solicitações de consultoria.',
    challenge:
      'A empresa possuía um site genérico que não refletia o ticket médio de sua carteira e gerava baixa taxa de resposta nas campanhas de busca.',
    solution:
      'Estruturamos uma arquitetura sóbria de alto contraste, com leitura executiva clara, indicadores em fonte tabular e fluxo direto para agendamento via WhatsApp.',
    stack: ['React', 'TypeScript', 'Tailwind CSS', 'Motion'],
    featured: true,
  },
  {
    id: 'aegean-residences',
    title: 'Vitrine Imobiliária — Empreendimentos Prime',
    client: 'Grupo Horizonte Incorporações',
    category: 'Vitrine',
    year: '2026',
    deliveryTime: 'Entregue no mesmo dia',
    impactMetric: '3,4x mais cliques em solicitação de visita pelo celular',
    image: '/src/assets/images/project_realestate_prime_1795547818650.jpg',
    summary:
      'Showcase imobiliário focado em arquitetura contemporânea, com galeria de alto impacto, ficha técnica objetiva e botão imediato de atendimento comercial.',
    challenge:
      'Compradores abandonavam a página no celular devido ao peso das imagens e à dificuldade de falar com um corretor.',
    solution:
      'Criamos uma vitrine mobile-first de carregamento rápido com contraste calibrado e CTA fixo direcionado diretamente à mesa de vendas.',
    stack: ['Design Responsivo', 'Otimização Mobile', 'WhatsApp Funnel'],
  },
  {
    id: 'avant-garde-retail',
    title: 'Página de Vendas — Coleção Executiva & Varejo',
    client: 'Avant-Garde Alfaiataria',
    category: 'Alta Conversão',
    year: '2026',
    deliveryTime: 'Entregue em 6 horas',
    impactMetric: '+92% no faturamento mensal vindo do tráfego pago',
    image: '/src/assets/images/project_ecommerce_premium_1795547818508.jpg',
    summary:
      'Experiência digital focada em conversão imediata para campanhas sazonais, unindo fotografia editorial, copywriting direto e atendimento consultivo.',
    challenge:
      'Os anúncios geravam cliques, mas o destino anterior era confuso e fazia os clientes saírem sem concluir o contato.',
    solution:
      'Desenvolvemos uma página enxuta e persuasiva, destacando os diferenciais das peças e levando o cliente com um toque para fechar o pedido no WhatsApp.',
    stack: ['Copywriting', 'UI Premium', 'Alta Conversão'],
  },
];

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  outcome: string;
  quote: string;
}

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    name: 'Rafael Mendes',
    role: 'Sócio-Diretor',
    company: 'Mendes & Duarte Engenharia',
    city: 'Goiânia, GO',
    outcome: '+140% em pedidos de orçamento em 45 dias',
    quote:
      'Fechamos o briefing pela manhã e no final da tarde o novo site já estava no ar. Antes perdíamos clientes pela aparência amadora do portal antigo; hoje os leads já chegam no WhatsApp confiando no nosso trabalho.',
  },
  {
    id: 't2',
    name: 'Camila Vasconcelos',
    role: 'Fundadora',
    company: 'Clínica Vitae Estética Avançada',
    city: 'São Paulo, SP',
    outcome: 'Agenda da semana lotada na primeira campanha',
    quote:
      'O que mais impressionou foi a velocidade sem abrir mão da sofisticação. O visual escuro com azul marinho elevou a percepção de valor da clínica e facilitou muito o agendamento direto pelo celular.',
  },
  {
    id: 't3',
    name: 'Henrique Alencar',
    role: 'Diretor Comercial',
    company: 'Alencar Logística Empresarial',
    city: 'Belo Horizonte, MG',
    outcome: '3 contratos corporativos fechados no 1º mês',
    quote:
      'A KL Studio entendeu exatamente o que precisávamos para vender mais para outras empresas. Texto claro, carregamento rápido e entrega realmente no mesmo dia. Investimento que se pagou na primeira semana.',
  },
];
